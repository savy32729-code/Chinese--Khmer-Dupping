# Chinese → Khmer Dubbing

Chinese video → Khmer subtitles/translation → Khmer voice dubbing.

## Flow

Upload → Transcribe (Chinese) → Translate (Khmer) → Khmer TTS → Create Dubbing → Download

## Backend

- FastAPI
- faster-whisper
- GoogleTranslator
- Edge TTS with automatic Google TTS fallback
- FFmpeg

## Render

Use the `backend` folder as the service root.

Build/runtime files:
- `backend/Dockerfile`
- `backend/requirements.txt`
- `backend/main.py`

The Dockerfile installs FFmpeg and starts Uvicorn on Render's `$PORT`.

## API

- `GET /` health/status
- `GET /health`
- `POST /upload`
- `POST /transcribe?filename=...`
- `POST /translate` (single text or segments)
- `POST /tts`
- `POST /create-dubbing`
- `GET /audio/{filename}`
- `GET /video/{filename}`

## Frontend

Open `frontend/index.html` from a static host. It uses:

`https://chinese-khmer-dupping.onrender.com`

The frontend sends translation segments in one request instead of one HTTP request per sentence, which is substantially faster and avoids repeated 422 failures.
