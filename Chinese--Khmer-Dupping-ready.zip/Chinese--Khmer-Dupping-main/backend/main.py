import os
import shutil
import subprocess
import uuid
import asyncio
import time
from pathlib import Path
from typing import Any

import edge_tts
from deep_translator import GoogleTranslator
from faster_whisper import WhisperModel

from fastapi import FastAPI, HTTPException, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field


# =========================================================
# APP
# =========================================================

APP_VERSION = "3.1.0"

app = FastAPI(
    title="Chinese-Khmer Dubbing API",
    version=APP_VERSION,
)


# =========================================================
# CORS
# =========================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =========================================================
# DIRECTORIES
# =========================================================

BASE_DIR = Path("/tmp")

UPLOAD_DIR = BASE_DIR / "uploads"
AUDIO_DIR = BASE_DIR / "audio"
OUTPUT_DIR = BASE_DIR / "output"

for directory in (UPLOAD_DIR, AUDIO_DIR, OUTPUT_DIR):
    directory.mkdir(parents=True, exist_ok=True)


# =========================================================
# SETTINGS
# =========================================================

ALLOWED_VIDEO_EXTENSIONS = {
    ".mp4",
    ".mov",
    ".mkv",
    ".avi",
    ".webm",
}

MAX_UPLOAD_BYTES = 500 * 1024 * 1024

WHISPER_MODEL_NAME = os.getenv(
    "WHISPER_MODEL",
    "tiny",
)

WHISPER_DEVICE = os.getenv(
    "WHISPER_DEVICE",
    "cpu",
)

WHISPER_COMPUTE_TYPE = os.getenv(
    "WHISPER_COMPUTE_TYPE",
    "int8",
)

DEFAULT_VOICE = os.getenv(
    "TTS_VOICE",
    "km-KH-PisethNeural",
)


# =========================================================
# WHISPER
# =========================================================

whisper_model = None
whisper_lock = asyncio.Lock()


async def get_whisper_model():
    global whisper_model

    if whisper_model is None:
        async with whisper_lock:
            if whisper_model is None:
                print(
                    f"Loading Whisper model: "
                    f"{WHISPER_MODEL_NAME}"
                )

                whisper_model = WhisperModel(
                    WHISPER_MODEL_NAME,
                    device=WHISPER_DEVICE,
                    compute_type=WHISPER_COMPUTE_TYPE,
                )

                print("Whisper model loaded.")

    return whisper_model


# =========================================================
# REQUEST MODELS
# =========================================================

class TranslateSegment(BaseModel):
    start: float
    end: float
    text: str


class TranslateRequest(BaseModel):
    text: str | None = None
    source: str = "zh"
    target: str = "km"
    segments: list[TranslateSegment] | None = None

class TTSRequest(BaseModel):
    text: str = Field(..., min_length=1)
    lang: str = "km"
    voice: str = DEFAULT_VOICE


class DubbingRequest(BaseModel):
    filename: str
    segments: list[dict[str, Any]]
    voice: str = DEFAULT_VOICE


# =========================================================
# HELPERS
# =========================================================

def safe_name(filename: str) -> str:
    return Path(filename).name


def run_command(
    command: list[str],
    timeout: int = 600,
) -> subprocess.CompletedProcess:

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"Command timeout after {timeout} seconds"
        ) from exc

    if result.returncode != 0:
        error = (
            result.stderr.strip()
            or result.stdout.strip()
            or "Unknown command error"
        )

        raise RuntimeError(
            error[-5000:]
        )

    return result


def split_text(
    text: str,
    max_chars: int = 2500,
) -> list[str]:

    text = text.strip()

    if not text:
        return []

    if len(text) <= max_chars:
        return [text]

    parts = []
    current = ""

    # Khmer/Chinese punctuation
    separators = [
        "។",
        "៕",
        "!",
        "?",
        "！",
        "？",
        "，",
        ",",
        " ",
    ]

    words = text

    for char in words:

        current += char

        if (
            len(current) >= max_chars
            and char in separators
        ):
            parts.append(current.strip())
            current = ""

    if current.strip():
        parts.append(current.strip())

    # Safety fallback
    final_parts = []

    for part in parts:
        if len(part) <= max_chars:
            final_parts.append(part)
        else:
            for i in range(
                0,
                len(part),
                max_chars,
            ):
                final_parts.append(
                    part[i:i + max_chars].strip()
                )

    return [
        p for p in final_parts
        if p
    ]


async def generate_tts_with_retry(
    text: str,
    output_file: Path,
    voice: str,
    retries: int = 3,
):
    """
    TTS with automatic fallback.

    1. Try Edge TTS
    2. If Edge TTS fails (403/503/network/etc.)
       automatically use Google TTS
    """

    text = text.strip()

    if not text:
        raise RuntimeError("TTS text is empty")

    chunks = split_text(
        text,
        max_chars=1800,
    )

    if not chunks:
        raise RuntimeError("No text for TTS")

    # =====================================================
    # 1. TRY EDGE TTS
    # =====================================================

    try:

        print(
            f"TTS: trying Edge TTS "
            f"({len(chunks)} chunk(s))"
        )

        chunk_files = []

        for index, chunk in enumerate(chunks):

            chunk_file = (
                output_file.parent
                / f"{output_file.stem}_edge_{index}.mp3"
            )

            success = False
            last_error = None

            for attempt in range(retries):

                try:

                    communicate = edge_tts.Communicate(
                        chunk,
                        voice,
                    )

                    await communicate.save(
                        str(chunk_file)
                    )

                    if (
                        chunk_file.exists()
                        and chunk_file.stat().st_size > 0
                    ):
                        success = True
                        break

                except Exception as exc:

                    last_error = exc

                    print(
                        f"Edge TTS attempt "
                        f"{attempt + 1}/{retries} "
                        f"failed: {exc}"
                    )

                    if attempt < retries - 1:
                        await asyncio.sleep(
                            2 ** attempt
                        )

            if not success:
                raise RuntimeError(
                    f"Edge TTS failed: {last_error}"
                )

            chunk_files.append(
                chunk_file
            )

        # ---------------------------------------------
        # Merge Edge chunks
        # ---------------------------------------------

        if len(chunk_files) == 1:

            shutil.copyfile(
                chunk_files[0],
                output_file,
            )

        else:

            concat_file = (
                output_file.parent
                / f"{output_file.stem}_edge_concat.txt"
            )

            with concat_file.open(
                "w",
                encoding="utf-8",
            ) as f:

                for file in chunk_files:

                    f.write(
                        "file '"
                        + str(file).replace(
                            "'",
                            "'\\''",
                        )
                        + "'\n"
                    )

            run_command(
                [
                    "ffmpeg",
                    "-y",
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    str(concat_file),
                    "-c:a",
                    "libmp3lame",
                    "-b:a",
                    "128k",
                    str(output_file),
                ],
                timeout=300,
            )

            concat_file.unlink(
                missing_ok=True
            )

        # Cleanup Edge chunks

        for file in chunk_files:
            file.unlink(
                missing_ok=True
            )

        if (
            output_file.exists()
            and output_file.stat().st_size > 0
        ):
            print(
                "TTS: Edge TTS succeeded"
            )
            return

    except Exception as edge_error:

        print(
            "TTS: Edge TTS unavailable. "
            f"Using Google TTS fallback. "
            f"Error: {edge_error}"
        )

        # Cleanup partial Edge files

        for file in output_file.parent.glob(
            f"{output_file.stem}_edge_*"
        ):
            file.unlink(
                missing_ok=True
            )

        output_file.unlink(
            missing_ok=True
        )

    # =====================================================
    # 2. GOOGLE TTS FALLBACK
    # =====================================================

    try:

        from gtts import gTTS

        print(
            f"TTS: using Google TTS fallback "
            f"({len(chunks)} chunk(s))"
        )

        chunk_files = []

        for index, chunk in enumerate(chunks):

            chunk_file = (
                output_file.parent
                / f"{output_file.stem}_google_{index}.mp3"
            )

            last_error = None

            for attempt in range(retries):

                try:

                    tts = gTTS(
                        text=chunk,
                        lang="km",
                        slow=False,
                    )

                    await asyncio.to_thread(
                        tts.save,
                        str(chunk_file),
                    )

                    if (
                        chunk_file.exists()
                        and chunk_file.stat().st_size > 0
                    ):
                        break

                except Exception as exc:

                    last_error = exc

                    print(
                        f"Google TTS attempt "
                        f"{attempt + 1}/{retries} "
                        f"failed: {exc}"
                    )

                    if attempt < retries - 1:
                        await asyncio.sleep(
                            2 ** attempt
                        )

            if not (
                chunk_file.exists()
                and chunk_file.stat().st_size > 0
            ):
                raise RuntimeError(
                    f"Google TTS failed: "
                    f"{last_error}"
                )

            chunk_files.append(
                chunk_file
            )

        # ---------------------------------------------
        # Merge Google chunks
        # ---------------------------------------------

        if len(chunk_files) == 1:

            shutil.copyfile(
                chunk_files[0],
                output_file,
            )

        else:

            concat_file = (
                output_file.parent
                / f"{output_file.stem}_google_concat.txt"
            )

            with concat_file.open(
                "w",
                encoding="utf-8",
            ) as f:

                for file in chunk_files:

                    f.write(
                        "file '"
                        + str(file).replace(
                            "'",
                            "'\\''",
                        )
                        + "'\n"
                    )

            run_command(
                [
                    "ffmpeg",
                    "-y",
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    str(concat_file),
                    "-c:a",
                    "libmp3lame",
                    "-b:a",
                    "128k",
                    str(output_file),
                ],
                timeout=300,
            )

            concat_file.unlink(
                missing_ok=True
            )

        # Cleanup

        for file in chunk_files:
            file.unlink(
                missing_ok=True
            )

        if (
            output_file.exists()
            and output_file.stat().st_size > 0
        ):
            print(
                "TTS: Google TTS fallback succeeded"
            )
            return

        raise RuntimeError(
            "Google TTS produced empty audio"
        )

    except Exception as google_error:

        output_file.unlink(
            missing_ok=True
        )

        raise RuntimeError(
            "All TTS providers failed. "
            f"Google TTS error: {google_error}"
        ) from google_error


# =========================================================
# HOME
# =========================================================

@app.get("/")
def home():

    return {
        "status": "ok",
        "message": (
            "Chinese-Khmer Dubbing API "
            "is running"
        ),
        "version": APP_VERSION,
    }


# =========================================================
# HEALTH
# =========================================================

@app.get("/health")
def health():

    return {
        "status": "healthy",
        "version": APP_VERSION,
    }

def cleanup_old_files(max_age_seconds=3600):
    now = time.time()

    for folder in [UPLOAD_DIR, AUDIO_DIR, OUTPUT_DIR]:
        if not os.path.exists(folder):
            continue

        for name in os.listdir(folder):
            path = os.path.join(folder, name)

            try:
                if os.path.isfile(path):
                    age = now - os.path.getmtime(path)

                    if age > max_age_seconds:
                        os.remove(path)

            except Exception as e:
                print(f"Cleanup warning: {path} -> {e}")
# =========================================================
# UPLOAD
# =========================================================

@app.post("/upload")
async def upload_video(
    file: UploadFile = File(...)
):
    try:
        if not file.filename:
            raise HTTPException(
                status_code=400,
                detail="No file selected"
            )

        original_name = Path(file.filename).name
        extension = Path(original_name).suffix.lower()

        if extension not in ALLOWED_VIDEO_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported video format: {extension}"
            )

        stem = Path(original_name).stem or "video"

        filename = f"{stem}_{uuid.uuid4().hex[:8]}{extension}"
        output_file = UPLOAD_DIR / filename

        print(f"UPLOAD START: {original_name}")
        print(f"UPLOAD PATH: {output_file}")

        total_bytes = 0

        with open(output_file, "wb") as buffer:
            while True:
                chunk = await file.read(1024 * 1024)

                if not chunk:
                    break

                total_bytes += len(chunk)
                if total_bytes > MAX_UPLOAD_BYTES:
                    raise HTTPException(
                        status_code=413,
                        detail=f"Video is too large. Maximum size is {MAX_UPLOAD_BYTES // (1024 * 1024)} MB",
                    )
                buffer.write(chunk)

        await file.close()

        print(f"UPLOAD DONE: {total_bytes} bytes")

        if total_bytes == 0:
            if output_file.exists():
                output_file.unlink()

            raise HTTPException(
                status_code=400,
                detail="Uploaded file is empty"
            )

        return {
            "status": "uploaded",
            "filename": filename,
            "size": total_bytes,
            "message": "Video uploaded successfully"
        }

    except HTTPException:
        raise

    except Exception as exc:
        print(f"UPLOAD ERROR: {type(exc).__name__}: {exc}")

        raise HTTPException(
            status_code=500,
            detail=f"Upload failed: {type(exc).__name__}: {exc}"
        ) from exc

# =========================================================
# TRANSCRIBE
# =========================================================

@app.post("/transcribe")
async def transcribe_video(filename: str):
    try:
        video_path = UPLOAD_DIR / Path(filename).name

        print(f"TRANSCRIBE FILE: {video_path}")

        if not video_path.exists():
            files = [
                f.name for f in UPLOAD_DIR.iterdir()
                if f.is_file()
            ]

            raise HTTPException(
                status_code=404,
                detail={
                    "message": f"Video not found: {filename}",
                    "available_files": files
                }
            )

        model = await get_whisper_model()

        segments, info = model.transcribe(
            str(video_path),
            language="zh",
            beam_size=1,
            vad_filter=True,
            condition_on_previous_text=False
        )

        results = []

        for segment in segments:
            text = segment.text.strip()

            if text:
                results.append({
                    "start": float(segment.start),
                    "end": float(segment.end),
                    "text": text
                })

        return {
            "status": "success",
            "filename": filename,
            "language": "zh",
            "segments": results
        }

    except HTTPException:
        raise

    except Exception as exc:
        print(f"TRANSCRIBE ERROR: {type(exc).__name__}: {exc}")

        raise HTTPException(
            status_code=500,
            detail=f"Transcription failed: {type(exc).__name__}: {exc}"
        )

# =========================================================
# TRANSLATE
# =========================================================

class TranslateRequest(BaseModel):
    text: str | None = None
    source: str = "zh"
    target: str = "km"
    segments: list[TranslateSegment] | None = None


@app.post("/translate")
async def translate(data: TranslateRequest):
    try:
        if data.segments:
            translator = GoogleTranslator(
                source=data.source,
                target=data.target,
            )
            output = []
            for segment in data.segments:
                text = segment.text.strip()
                if not text:
                    continue
                translated = await asyncio.to_thread(
                    translator.translate,
                    text,
                )
                output.append({
                    "start": float(segment.start),
                    "end": float(segment.end),
                    "text": text,
                    "translation": translated or text,
                })
            return {
                "status": "success",
                "source": data.source,
                "target": data.target,
                "segments": output,
            }

        text = (data.text or "").strip()
        if not text:
            raise HTTPException(
                status_code=422,
                detail="text or segments is required",
            )

        translator = GoogleTranslator(
            source=data.source,
            target=data.target,
        )
        result = await asyncio.to_thread(
            translator.translate,
            text,
        )

        return {
            "status": "success",
            "original": text,
            "translation": result or text,
            "source": data.source,
            "target": data.target,
        }

    except HTTPException:
        raise
    except Exception as exc:
        print(f"TRANSLATION ERROR: {type(exc).__name__}: {exc}")
        raise HTTPException(
            status_code=500,
            detail=f"Translation failed: {type(exc).__name__}: {exc}",
        ) from exc


# =========================================================
# TTS
# =========================================================

@app.post("/tts")
async def text_to_speech(
    data: TTSRequest,
):

    cleanup_old_files()

    text = data.text.strip()

    if not text:
        raise HTTPException(
            status_code=400,
            detail="Text cannot be empty",
        )

    voice = (
        data.voice.strip()
        if data.voice
        else DEFAULT_VOICE
    )

    filename = (
        f"{uuid.uuid4().hex}.mp3"
    )

    filepath = (
        AUDIO_DIR / filename
    )

    try:

        await generate_tts_with_retry(
            text=text,
            output_file=filepath,
            voice=voice,
            retries=3,
        )

        return {
            "success": True,
            "filename": filename,
            "voice": voice,
            "audio_url": (
                f"/audio/{filename}"
            ),
        }

    except Exception as exc:

        filepath.unlink(
            missing_ok=True
        )

        print(
            f"TTS ERROR: {exc}"
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "TTS generation failed: "
                f"{str(exc)}"
            ),
        ) from exc


# =========================================================
# CREATE DUBBING
# =========================================================

@app.post("/create-dubbing")
async def create_dubbing(
    data: DubbingRequest,
):

    cleanup_old_files()

    safe_filename = safe_name(
        data.filename
    )

    video_file = (
        UPLOAD_DIR / safe_filename
    )

    if not video_file.exists():
        raise HTTPException(
            status_code=404,
            detail="Video file not found",
        )

    if not data.segments:
        raise HTTPException(
            status_code=400,
            detail="No dubbing segments",
        )

    job_id = uuid.uuid4().hex

    work_dir = (
        BASE_DIR
        / f"dubbing_{job_id}"
    )

    work_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    try:

        # -----------------------------------------
        # Get video duration
        # -----------------------------------------

        probe = run_command(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                str(video_file),
            ],
            timeout=60,
        )

        duration = float(
            probe.stdout.strip()
        )

        if duration <= 0:
            raise RuntimeError(
                "Invalid video duration"
            )

        # -----------------------------------------
        # Generate TTS
        # -----------------------------------------

        audio_files = []

        voice = (
            data.voice.strip()
            if data.voice
            else DEFAULT_VOICE
        )

        for index, segment in enumerate(
            data.segments
        ):

            if not isinstance(
                segment,
                dict,
            ):
                continue

            text = str(
                segment.get(
                    "translation",
                    segment.get(
                        "text",
                        "",
                    ),
                )
            ).strip()

            if not text:
                continue

            try:
                start = float(
                    segment.get(
                        "start",
                        0,
                    )
                )
            except Exception:
                start = 0

            try:
                end = float(
                    segment.get(
                        "end",
                        start + 1,
                    )
                )
            except Exception:
                end = start + 1

            start = max(
                0,
                start,
            )

            end = max(
                start + 0.1,
                end,
            )

            # Do not put audio outside video
            if start >= duration:
                continue

            end = min(
                end,
                duration,
            )

            tts_file = (
                work_dir
                / f"tts_{index}.mp3"
            )

            await generate_tts_with_retry(
                text=text,
                output_file=tts_file,
                voice=voice,
                retries=3,
            )

            audio_files.append(
                {
                    "file": tts_file,
                    "start": start,
                    "end": end,
                }
            )

        if not audio_files:
            raise RuntimeError(
                "No valid TTS segments"
            )

        # -----------------------------------------
        # Base silent audio
        # -----------------------------------------

        base_audio = (
            work_dir
            / "base_audio.wav"
        )

        run_command(
            [
                "ffmpeg",
                "-y",
                "-f",
                "lavfi",
                "-i",
                "anullsrc=r=44100:cl=stereo",
                "-t",
                str(duration),
                "-c:a",
                "pcm_s16le",
                str(base_audio),
            ],
            timeout=300,
        )

        # -----------------------------------------
        # Build inputs
        # -----------------------------------------

        inputs = [
            "-i",
            str(base_audio),
        ]

        for item in audio_files:

            inputs.extend(
                [
                    "-i",
                    str(item["file"]),
                ]
            )

        # -----------------------------------------
        # Build filters
        # -----------------------------------------

        filters = [
            "[0:a]anull[a0]"
        ]

        mix_inputs = [
            "[a0]"
        ]

        for index, item in enumerate(
            audio_files,
            start=1,
        ):

            delay_ms = max(
                0,
                int(
                    item["start"] * 1000
                ),
            )

            filters.append(
                f"[{index}:a]"
                f"adelay={delay_ms}:all=1,"
                f"aresample=44100,"
                f"volume=1.0"
                f"[a{index}]"
            )

            mix_inputs.append(
                f"[a{index}]"
            )

        filter_complex = (
            ";".join(filters)
            + ";"
            + "".join(mix_inputs)
            + f"amix=inputs={len(mix_inputs)}:"
              "duration=longest:"
              "dropout_transition=0,"
              "aresample=44100"
              "[mixed]"
        )

        # -----------------------------------------
        # Output
        # -----------------------------------------

        output_filename = (
            f"khmer_dubbed_{job_id}.mp4"
        )

        output_file = (
            OUTPUT_DIR
            / output_filename
        )

        command = [
            "ffmpeg",
            "-y",

            "-i",
            str(video_file),

            *inputs,

            "-filter_complex",
            filter_complex,

            "-map",
            "0:v:0",

            "-map",
            "[mixed]",

            "-c:v",
            "libx264",

            "-preset",
            "veryfast",

            "-crf",
            "23",

            "-c:a",
            "aac",

            "-b:a",
            "128k",

            "-t",
            str(duration),

            "-movflags",
            "+faststart",

            str(output_file),
        ]

        run_command(
            command,
            timeout=1200,
        )

        if (
            not output_file.exists()
            or output_file.stat().st_size <= 0
        ):
            raise RuntimeError(
                "FFmpeg did not create output video"
            )

        return {
            "success": True,
            "filename": output_filename,
            "video_url": (
                f"/video/{output_filename}"
            ),
            "message": (
                "Khmer dubbed video "
                "created successfully"
            ),
        }

    except HTTPException:
        raise

    except Exception as exc:

        print(
            f"DUBBING ERROR: {exc}"
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "Dubbing failed: "
                f"{str(exc)}"
            ),
        ) from exc

    finally:

        # IMPORTANT:
        # This now ALWAYS runs.
        shutil.rmtree(
            work_dir,
            ignore_errors=True,
        )


# =========================================================
# AUDIO
# =========================================================

@app.get("/audio/{filename}")
async def get_audio(
    filename: str,
):

    safe_filename = safe_name(
        filename
    )

    filepath = (
        AUDIO_DIR / safe_filename
    )

    if not filepath.exists():
        raise HTTPException(
            status_code=404,
            detail="Audio file not found",
        )

    return FileResponse(
        path=str(filepath),
        media_type="audio/mpeg",
        filename=safe_filename,
    )


# =========================================================
# VIDEO
# =========================================================

@app.get("/video/{filename}")
async def get_video(
    filename: str,
):

    safe_filename = safe_name(
        filename
    )

    filepath = (
        OUTPUT_DIR / safe_filename
    )

    if not filepath.exists():
        raise HTTPException(
            status_code=404,
            detail="Video file not found",
        )

    return FileResponse(
        path=str(filepath),
        media_type="video/mp4",
        filename=safe_filename,
    )


# =========================================================
# SERVER
# =========================================================

if __name__ == "__main__":

    import uvicorn

    port = int(
        os.environ.get(
            "PORT",
            "10000",
        )
    )

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
    )
