const API_URL = "https://chinese-khmer-dupping.onrender.com";

const videoInput = document.getElementById("videoInput");
const videoInfo = document.getElementById("videoInfo");
const duration = document.getElementById("duration");
const translateToggle = document.getElementById("translateToggle");
const voiceSelect = document.getElementById("voiceSelect");
const startBtn = document.getElementById("startBtn");

const progressCard = document.getElementById("progressCard");
const progressFill = document.getElementById("progressFill");
const percentage = document.getElementById("percentage");
const progressText = document.getElementById("progressText");
const processingStatus = document.getElementById("processingStatus");

const resultsCard = document.getElementById("resultsCard");
const partsList = document.getElementById("partsList");
const saveBtn = document.getElementById("saveBtn");

let selectedFile = null;


// ================================
// VIDEO SELECT
// ================================

videoInput.addEventListener("change", () => {

    selectedFile = videoInput.files[0];

    if (!selectedFile) {
        videoInfo.textContent = "មិនទាន់បានជ្រើស Video";
        duration.textContent = "";
        startBtn.disabled = true;
        return;
    }

    videoInfo.textContent =
        `📹 ${selectedFile.name}`;

    const sizeMB =
        (selectedFile.size / 1024 / 1024).toFixed(2);

    duration.textContent =
        `ទំហំ: ${sizeMB} MB`;

    startBtn.disabled = false;

});


// ================================
// PROGRESS
// ================================

function setProgress(value, text) {

    progressFill.style.width = `${value}%`;

    percentage.textContent =
        `${value}%`;

    progressText.textContent =
        text;

}


// ================================
// START DUBBING
// ================================

startBtn.addEventListener("click", async () => {

    if (!selectedFile) {
        alert("សូមជ្រើស Video ជាមុនសិន");
        return;
    }

    startBtn.disabled = true;

    progressCard.classList.remove("hidden");
    resultsCard.classList.add("hidden");

    setProgress(
        5,
        "កំពុង Upload Video..."
    );

    try {

        // =========================
        // 1. UPLOAD
        // =========================

        const formData = new FormData();

        formData.append(
            "file",
            selectedFile
        );

        const uploadResponse =
            await fetch(
                `${API_URL}/upload`,
                {
                    method: "POST",
                    body: formData
                }
            );

        if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            throw new Error(`Upload Video បរាជ័យ: ${errorText}`);
        }

        const uploadData =
            await uploadResponse.json();

        setProgress(
            20,
            "Upload បានជោគជ័យ..."
        );


        // =========================
        // 2. TRANSCRIBE
        // =========================

        const filename =
            uploadData.filename ||
            selectedFile.name;

        setProgress(
            30,
            "កំពុងស្តាប់សំឡេងក្នុង Video..."
        );

        const transcribeResponse =
            await fetch(
                `${API_URL}/transcribe?filename=${encodeURIComponent(filename)}`,
                {
                    method: "POST"
                }
            );

        if (!transcribeResponse.ok) {
            const errorText = await transcribeResponse.text();
            throw new Error(`Transcribe បរាជ័យ: ${errorText}`);
        }

        const transcribeData =
            await transcribeResponse.json();

        let segments =
            transcribeData.segments || [];

        if (!segments.length) {
            throw new Error(
                "រកមិនឃើញសំឡេងក្នុង Video"
            );
        }


        // =========================
        // 3. TRANSLATE
        // =========================

        if (translateToggle.checked) {

            setProgress(
                45,
                `កំពុងបកប្រែ ${segments.length} ប្រយោគ...`
            );

            const translateResponse = await fetch(
                `${API_URL}/translate`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        source: "zh",
                        target: "km",
                        segments: segments.map(s => ({
                            start: Number(s.start) || 0,
                            end: Number(s.end) || 0,
                            text: s.text || ""
                        }))
                    })
                }
            );

            if (!translateResponse.ok) {
                const errorText = await translateResponse.text();
                throw new Error(
                    `Translation បរាជ័យ: ${errorText}`
                );
            }

            const translateData = await translateResponse.json();
            const translated = translateData.segments || [];

            if (!translated.length) {
                throw new Error("មិនអាចបកប្រែបាន");
            }

            segments = translated;
            setProgress(
                70,
                `បកប្រែរួចរាល់ ${translated.length} ប្រយោគ`
            );

        } else {

            segments.forEach(segment => {
                segment.translation = segment.text || "";
            });

        }


        // =========================
        // 4. CREATE DUBBING
        // =========================

        setProgress(
            75,
            "កំពុងបង្កើតសំឡេងខ្មែរ..."
        );

        processingStatus.textContent =
            `🎙️ សំឡេង: ${voiceSelect.value}`;


        const dubbingResponse =
            await fetch(
                `${API_URL}/create-dubbing`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        filename: filename,

                        voice:
                            voiceSelect.value,

                        segments:
                            segments

                    })
                }
            );


        if (!dubbingResponse.ok) {

            const errorText =
                await dubbingResponse.text();

            throw new Error(
                `Dubbing បរាជ័យ: ${errorText}`
            );

        }


        const dubbingData =
            await dubbingResponse.json();


        setProgress(
            95,
            "កំពុងរៀបចំ Video ចុងក្រោយ..."
        );


        // =========================
        // 5. RESULT
        // =========================

        const outputFilename =
            dubbingData.filename ||
            filename;

        const videoUrl =
            `${API_URL}/video/${encodeURIComponent(outputFilename)}`;


        setProgress(
            100,
            "រួចរាល់! 🎉"
        );


        saveBtn.href =
            videoUrl;

        partsList.innerHTML = "";


        const resultInfo =
            document.createElement("div");

        resultInfo.className =
            "result-item";

        resultInfo.textContent =
            "✅ Video Khmer ត្រូវបានបង្កើតរួចរាល់";

        partsList.appendChild(
            resultInfo
        );


        resultsCard.classList.remove(
            "hidden"
        );


    } catch (error) {

        console.error(error);

        alert(
            error.message ||
            "មានបញ្ហា សូមព្យាយាមម្តងទៀត"
        );

        progressText.textContent =
            "❌ មានបញ្ហា";

        processingStatus.textContent =
            error.message || "";

    } finally {

        startBtn.disabled = false;

    }

});
